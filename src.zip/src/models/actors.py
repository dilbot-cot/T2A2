from main import db
import datetime


# Director Model
class Actor():
    __tablename__ = 'actors'
    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String, nullable=False)
    dob = db.Columns(datetime, nullable=False)