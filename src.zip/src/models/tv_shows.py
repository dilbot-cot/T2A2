from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship
from main import db

# TVShow Model
class TVShow():
    __tablename__ = 'tv_shows'
    id = db.Column(db.Integer, primary_key=True)
    
    title = db.Column(db.String, nullable=False)
    genre_id = db.Column(db.Integer, ForeignKey('genres.id'), nullable=False)

    # Relationships
    genre = relationship('Genre', back_populates='tv_shows')