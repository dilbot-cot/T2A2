from main import db
import datetime


# Director Model
class Director():
    __tablename__ = 'directors'
    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String, nullable=False)
    dob = db.Column(datetime, nullable=False)