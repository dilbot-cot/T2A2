from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship
from main import db
import datetime

# Movie Model
class Movie():
    __tablename__ = 'movies'
    id = db.Column(db.Integer, primary_key=True)

    title = db.Column(db.String, nullable=False)
    release_date = db.Columns(datetime, nullable=False)
    genre_id = db.Column(db.Integer, ForeignKey('genres.id'), nullable=False)

    # Relationships
    genre = relationship('Genre', back_populates='movies')