from .actors_schema import ActorSchema
from .directors_schema import DirectorSchema
from .genres_schema import GenreSchema
from .movies_schema import MovieSchema
from .reviews_schema import ReviewSchema
from .tv_shows_schema import TVShowSchema
from .users_schema import UserSchema