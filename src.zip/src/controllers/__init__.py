from controllers.actors_controller import actors

registerable_controllers = [
    actors
]